# Inshackle v2.3
# Instagram bot,auto follower
## Recoded: github.com/cyberkallan/inshackle-bot
## IG: https://instagram.com/imarjunarz
## subscribe my YouTube channel - https://youtube.com/c/CYBERKALLAN2
### Don't copy this code without give me the credits, nerd! Please read the License 
### thanks to linuxchoice
Instagram hacks: Track unfollowers, Increase your followers, Download Stories, etc

#### Download Hacking tools : https://denotech.in

### Features:
#### Unfollow Tracker
#### Increase Followers
#### Download: Stories, Saved Content, Following/followers list, Profile Info
#### Unfollow all your following

![ins](https://user-images.githubusercontent.com/56509491/66778205-b18ad580-eee8-11e9-8904-2c536b1a365d.JPG)

### Usage:
```
git clone https://github.com/cyberkallan/inshackle-bot
cd inshackle-bot
bash inshackle.sh
```

## by arjun arz

![cb](https://user-images.githubusercontent.com/56509491/66774387-15100580-eedf-11e9-84ff-c0f396016bd5.jpg)

### Donate!
Support the authors:
### Google pay,phone pay,UPI.

### Buymeacoffie
https://www.buymeacoffee.com/Cyberkallan

### LiberaPay:
<noscript><a href="https://liberapay.com/thelinuxchoice/donate"><img alt="Donate using Liberapay" src="https://liberapay.com/assets/widgets/donate.svg"></a></noscript>
